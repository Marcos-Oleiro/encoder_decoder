package encoder_decoder;


import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;


public class Decoder {
	
	private BufferedReader bf;

	public Decoder(BufferedReader bf) {
		this.bf = bf;
	}
	
	
	public Book makeABook (){
		String s;
		Book b = new Book();
		int i;
		
		
		try {
			s = this.bf.readLine();
			ArrayList<String[]>  t = new ArrayList(); 
			String[] aux = s.split("\",");

			
			// Setar a ID do livro
			b.setId(Integer.parseInt(aux[0].split("\"")[1]));
			
			
			// Saber qual a quantidade de títulos que o documento tem
			int number_of_titles = Integer.parseInt(aux[1].split("\"")[1]);
			
			// For para percorrer os campos do arquivo e setando os titulos contidos nele no objeto livro
			for ( i = 2 ; i <= (1 + 2*number_of_titles); i++ ){
				
				String[] title_array = new String[2];
				if ( i % 2 == 0){
					title_array[0] = aux[i].split("\"")[1];	
					title_array[1] = aux[i+1].split("\"")[1];	

					t.add(title_array);
				}
			}
			b.setTitles(t);
			

			// Data de publicação
			
			int index_publishing_date = 1 + 2*number_of_titles + 1;
			
			String aux_data = aux[index_publishing_date].split("\"")[1];

			b.setPublish_date(LocalDate.of(Integer.parseInt(aux_data.split("-")[0]),
										   Integer.parseInt(aux_data.split("-")[1]),
										   Integer.parseInt(aux_data.split("-")[2])));
			
			// Editora
			
			int index_publishing = index_publishing_date + 1;
			
			b.setPublishing(aux[index_publishing].split("\"")[1]);
			
			// Autores
			
			ArrayList<String> authors = new ArrayList();
			int index_of_number_author = index_publishing + 1;
			int number_of_authors = Integer.parseInt(aux[index_of_number_author].split("\"")[1]);

			int aux_int = number_of_authors +index_of_number_author + 1;
			
			for (i = index_of_number_author + 1; i < aux_int; i++) {

				authors.add(aux[i].split("\"")[1]);
			}
			
			b.setAuthors(authors);
			
			// Formato da capa
			
			int index_of_cover_format = index_of_number_author + number_of_authors + 1;
			int index_of_cover= index_of_cover_format + 1;
			b.setCover_type(aux[index_of_cover_format].split("\"")[1]);
			b.setCover(aux[index_of_cover].split("\"")[1]);
			
			return b;
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

}
