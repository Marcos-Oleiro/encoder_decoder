package encoder_decoder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

//		String path = "/home/spellzito/example.csv";
		String path = "/home/aluno/example.csv";
//		String cover_path = "/home/spellzito/capa_livro.jpeg";
		String cover_path = "/home/aluno/capa_livro.jpeg";
		
//		FileDecoder fd = new FileDecoder(cover_path);
//		String aux = fd.encodeToBase64();
//		System.out.println(aux);
//		fd.encodetoString(aux);
		
//		System.out.println(new FileDecoder(path).hashToMD5(cover_path));
		
		
//		BufferedReader bf = null;
//		Path p = Paths.get(path);
//		try {
//			
//			bf = Files.newBufferedReader(p);
//			Decoder d = new Decoder(bf);
//			Book b = new Book();
//			b = d.makeABook();
//			
//			System.out.println("-------------------------------");
//			System.out.println("Testando função");
//			System.out.println("ID: " + b.getId());
//			System.out.println("Títulos : " );
//			for (int j = 0; j < b.getTitles().size(); j++){
//				System.out.println(b.getTitles().get(j)[0]);
//				System.out.println(b.getTitles().get(j)[1]);
//			}
//			System.out.println("Data de Publicação: " + b.getPublish_date());
//			System.out.println("Editora: " + b.getPublishing());
//			System.out.println("Autores: ");
//			for (int j = 0; j < b.getAuthors().size(); j++){
//				System.out.println(b.getAuthors().get(j));
//			}
//			System.out.println(b.getCover_type());
//			System.out.println(b.getCover().length());
//			System.out.println("-------------------------------");
//			
//			
//			Encoder e = new Encoder(b);
//			String json = e.makeAJSON();
//			
//			String path_json = "/home/spellzito/book.json";
//			Path p1 = Paths.get(path_json);
//			FileWriter fw = new FileWriter(path_json);
//			BufferedWriter bw = new BufferedWriter(fw);
//			bw.write(json);
//			bw.flush();
//			
		Scanner scan = new Scanner(System.in);
		String[] titles = new String[2];
		ArrayList<String[]> titles_list = new ArrayList();
		ArrayList<String> authors_list = new ArrayList();
		int i;
		System.out.print("Informe o ID do livro: ");
		int id_book = Integer.parseInt(scan.nextLine());
		
		System.out.print("Informe o número de títulos: ") ;
		int number_of_titles= Integer.parseInt(scan.nextLine());
		
		for (i = 0 ; i < number_of_titles; i++) {
			System.out.print("Informe o idioma do título: ");
			titles[0] = scan.nextLine();
			System.out.print("Informe o título: ");
			titles[1] = scan.nextLine();
			titles_list.add(titles);			
		}
		
		System.out.print("Informe a data de publicação (yyyy-mm-dd)");
		String aux = scan.nextLine();
		int year, month, day;
		year = Integer.parseInt(aux.split("-")[0]);
		month = Integer.parseInt(aux.split("-")[1]);
		day = Integer.parseInt(aux.split("-")[2]);
		LocalDate publish_date =  LocalDate.of(year, month, day);
		
		System.out.print("Informe a editora: ");
		String publishing = scan.nextLine();
		
		System.out.print("Informe a quantidade de autores: ");
		int number_of_authors = Integer.parseInt(scan.nextLine());
		
		for ( i = 0 ; i < number_of_authors ; i++) {
			System.out.println("Informe o nome do autor: ");
			authors_list.add(scan.nextLine());
		}
		
		System.out.println("Informe a extensão do arquivo da capa: ");
		String cover_type = scan.nextLine();
		
		System.out.println("Informe o caminho do arquivo da capa: ");
		String path_cover = scan.nextLine();
		FileDecoder fd = new FileDecoder();
		fd.setPath(path_cover);
		String cover_64 = fd.encodeToBase64();
		
		Book b1 = new Book();
		b1.setId(id_book);
		b1.setAuthors(authors_list);
		b1.setCover(cover_64);
		b1.setCover_type(cover_type);
		b1.setPublish_date(publish_date);
		b1.setPublishing(publishing);
		b1.setTitles(titles_list);
		
		Encoder e = new Encoder(b1);
		String json = e.makeAJSON();
		
//		String path_json = "/home/spellzito/book.json";
		String path_json = "/home/aluno/book.json";
		Path p1 = Paths.get(path_json);
		FileWriter fw;
		try {
			fw = new FileWriter(path_json);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(json);
			bw.flush();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
//			
//			FileDecoder fd = new FileDecoder();
//			fd.encodetoFile(b.getCover());
//			
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}
//		

	}

}
